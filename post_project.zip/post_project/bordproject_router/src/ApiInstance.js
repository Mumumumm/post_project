import axios from "axios";
import store, {setToken} from "./Store";

const apiClient = axios.create({
    baseURL:"http://localhost:8080",
    headers:{
        "Content-Type":"application/json",
    },
    timeout: 10000,
    withCredentials:true,
});

apiClient.interceptors.request.use(config=>{
 if (config.data && config.data instanceof URLSearchParams){
    config.headers['content-type'] = "application/x-www-form-urlencoded";
 }

const jwtToken = store.getState().token.token;
config.headers['authorization'] = jwtToken;
return config;
},(error)=>{
    return Promise.reject(error)
});

apiClient.interceptors.response.use((response)=>response,
    async (error) =>{
    const originalRequest = error.config;
    if(error.response && error.response.status === 403 && !originalRequest._retry){
        originalRequest._retry = true;
        try {
            const response =  await axios.post("http://localhost:8080",null,{
                withCredentials:true,
            });
            const access = response.headers['authorization'];
            store.dispatch(setToken(access));
            return apiClient(originalRequest);

        }catch (error){
            console.log("리프레시 토큰으로 재발급 실패", error);
            return Promise.reject(error);
        }
    }
    return Promise.reject(error);
    });

export default apiClient;