import {configureStore, createSlice} from "@reduxjs/toolkit";



const initState:{token:null}={
    token:null,
    loginflag: false,
}

const tokenSlice = createSlice({
    name:"token",
    initialState: initState,
    reducers:{
        setToken:(state, action)=>{
            state.token = action.payload;
        },
        setLoginFlag: (state, action) => {
            state.loginflag = action.payload;
        },
    }
});

const store = configureStore({
    reducer:{
        token:tokenSlice.reducer,
    }
});
export const {setToken,setLoginFlag} = tokenSlice.actions;
export default store;