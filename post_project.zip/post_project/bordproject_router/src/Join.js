import apiClient from "./ApiInstance";
import store, {setLoginFlag, setToken} from "./Store";
import {useNavigate} from "react-router-dom";
import {useDispatch} from "react-redux";
import {useState} from "react";

export default function Join() {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [message, setMessage] = useState(null);

    const handlesubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await apiClient.post("/join",
                {
                    username: e.target.joinid.value,
                    password: e.target.joinpw.value,
                });
            console.log("가입 완료 😉");
            navigate("/");
            dispatch(setLoginFlag(true));
        } catch (error) {
            if (error.response && error.response.status === 401) {
                setMessage(error.response.data.result);
            } else {
                console.log(error);
            }
        }
    }


    return (
        <>
            <form onSubmit={handlesubmit}>
                <label htmlFor={"joinid"}>가입 아이디: </label>
                <input id={"joinid"} type={"text"}/>
                <label htmlFor={"joinpw"}>가입 비밀번호: </label>
                <input id={"joinpw"} type={"password"}/>
                <button type={"submit"}>가입하기</button>
            </form>
        </>
    );
}