import {useDispatch} from "react-redux";
import {useEffect} from "react";

export default function Logout(){

    useEffect(() => {

        const fetchData = async ()=>{
            try{
            }catch(error){
            }
        };
        fetchData();
    }, []);

    return(
        <>
        </>
    );
}