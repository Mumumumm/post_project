import apiClient from "./ApiInstance";
import store, {setLoginFlag, setToken} from "./Store";
import {useState} from "react";
import {useNavigate} from "react-router-dom";
import {useDispatch} from "react-redux";

export default function Login(){
    const [message, setMessage] = useState(null);
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const handlesubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await apiClient.post("/login",
                new URLSearchParams({
                    username:e.target.userid.value,
                    password:e.target.userpw.value,
                }));
            console.log(setToken(response.headers['authorization']));
            console.log(response.headers['authorization']);
            console.log("로그인 완료. 현재 토큰 상태:", store.getState().token.token);
            navigate("/");
            dispatch(setLoginFlag(true));
        }catch (error){
            if (error.response && error.response.status === 401){
                setMessage(error.response.data.result);
            }else {
                console.log(error);
            }
        }
    }

    return(
        <>
            <form onSubmit={handlesubmit}>
                <label htmlFor={"userid"}>아이디: </label>
                <input id={"userid"} type={"text"} name={"userid"} required/>
                <label htmlFor={"userpw"}>비밀번호: </label>
                <input id={"userpw"} type={"password"} name={"userpw"} required/>
                <button type={"submit"}>로그인</button>
            </form>
        </>
    );
}