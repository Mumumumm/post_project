
import { useState } from 'react';
import Header from './Header';
import Menu from './Menu';
import PostList from './PostList';
import PostWrite from './PostWrite';
import ReadPost from './ReadPost';
import {BrowserRouter, Route, Routes} from 'react-router-dom';
import MainLayout from './MainLayout';
import Login from "./Login";
import Join from "./Join";
import Logout from "./Logout";

function App() {
  return(
    <>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<MainLayout/>}>
          <Route index element={<PostList/>}></Route>
          <Route path={"/login"} element={<Login/>}></Route>
          <Route path={"/join"} element={<Join/>}></Route>
          <Route path="/write" element={<PostWrite/>}></Route>
          <Route path="/post/:postId" element={<ReadPost/>}></Route>
          <Route path={"/logout"} element={<Logout/>}></Route>
        </Route>
      </Routes>
    </BrowserRouter>
    </>
  );
  
}

export default App;
