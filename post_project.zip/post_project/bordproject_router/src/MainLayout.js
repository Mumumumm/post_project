import {Link, Outlet, useNavigate} from "react-router-dom";
import { useState } from "react";
import Header from "./Header";
import Menu from "./Menu";
import {useSelector} from "react-redux";
export default function MainLayout() {
  const style = {marginRight:"5px" , marginLeft:"5px"};
  const [postList, setPostList] = useState([
    { id: 1, title: "반갑습니다.", body: "Hello", writer: "김준홍" },
    { id: 2, title: "안녕하세요", body: "안녕하세요", writer: "김준홍" },
  ]);

  const loginflag = useSelector(state => state.token.loginflag);

  const [nextId, setNextId] = useState(postList.length + 1);
  const navigate = useNavigate();

  const onSave = (title, body, writer) => {
    const post = { id: nextId, title, body, writer }; //{id:3, title:"hi", body:"...", writer:"김준홍"}
    postList.push(post);
    const newPostList = [...postList];
    setPostList(newPostList);
    setNextId(nextId + 1);
    navigate("/");
  };

  const onUpdate = (id, title, body, writer) => {
    const updatePost = { id, title, body, writer };
    for (let i = 0; i < postList.length; i++) {
      if (postList[i].id === Number(id)) {
        postList[i] = updatePost;
        break;
      }
    }
    const newPostList = [...postList];
    setPostList(newPostList);
    navigate("/");
  };

  const onDelete = (id) => {
    const newPostList = postList.filter((post) => post.id !== Number(id));
    setPostList(newPostList);
    navigate("/");
  };

  return (
    <>
      {loginflag ?
      (<>
        <Header title="글목록"></Header>
        <Link to={"/write"} style={style}>글쓰기</Link>|
        <Link to={"/"} style={style}>목록으로</Link>|
        <Link to={"/logout"} style={style}>로그아웃</Link>|
        <Link to={"/join"} style={style}>가입</Link>
        <Outlet context={{ postList, onSave, onUpdate, onDelete }} />
        {/*flag가 참일때*/}
      </>)
          :
      (<>
         <Header title="글목록"></Header>
         <Link to={"/write"} style={style}>글쓰기</Link>|
         <Link to={"/"} style={style}>목록으로</Link>|
         <Link to={"/login"} style={style}>로그인</Link>|
         <Link to={"/join"} style={style}>가입</Link>
         <Outlet context={{ postList, onSave, onUpdate, onDelete }} />
        {/*flag가 거짓일때*/}
      </>)}
    </>
  );
}