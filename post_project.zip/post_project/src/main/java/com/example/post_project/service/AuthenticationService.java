package com.example.post_project.service;

import com.example.post_project.data.entity.AuthenEntity;
import com.example.post_project.data.repository.AuthenRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AuthenticationService implements UserDetailsService {

    private final AuthenRepository authenRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        AuthenEntity authenEntity = this.authenRepository.findById(username).orElse(null);
        if (authenEntity == null) {
            throw new UsernameNotFoundException(username);
        }
        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        return new User(authenEntity.getUsername(), authenEntity.getPassword(), grantedAuthorities);
    }

    public AuthenEntity saveAuthen(String username, String password) {
        AuthenEntity authen = AuthenEntity.builder()
                .username(username)
                .password(this.passwordEncoder.encode(password))
                .accession(LocalDate.now())
                .build();

        authenRepository.save(authen);
        return authen;
    }

    public boolean isUsernameExists(String username) {
        return authenRepository.existsById(username);
    }
}
