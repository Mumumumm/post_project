package com.example.post_project.config;

import com.example.post_project.component.CustomAccessDeniedHandler;
import com.example.post_project.component.CustomAuthenticationEntryPoint;
import com.example.post_project.jwt.JwtFilter;
import com.example.post_project.jwt.JwtLoginFilter;
import com.example.post_project.jwt.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.web.cors.CorsConfiguration;

import java.util.List;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtUtil jwtUtil;
    private final AuthenticationConfiguration authenticationConfiguration;
    private final CustomAccessDeniedHandler customAccessDeniedHandler;
    private final CustomAuthenticationEntryPoint customAuthenticationEntryPoint;

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public LogoutSuccessHandler logoutSuccessHandler() {
        return((request, response, auth) -> {
            response.setStatus(200);
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("로그아웃 성공");
        });
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf->csrf.disable())
            .formLogin(formLogin->formLogin.disable())
            .httpBasic(httpBasic->httpBasic.disable())
                .authorizeHttpRequests(authorizeRequest->{
                    authorizeRequest.requestMatchers("/","/join","/login","/reissue","logout").permitAll();
                    authorizeRequest.anyRequest().authenticated();
                })

            .cors(cors->cors.configurationSource(request -> {
                CorsConfiguration corsConfiguration = new CorsConfiguration();
                corsConfiguration.addAllowedOrigin("http://localhost:3000");
                corsConfiguration.addAllowedHeader("*");
                corsConfiguration.setExposedHeaders(List.of("Authorization"));
                corsConfiguration.setAllowedMethods(List.of("GET","POST","PUT","DELETE","OPTIONS")); //set으로 여러개 담기
                corsConfiguration.setAllowCredentials(true);
                return corsConfiguration;
            }))
            .sessionManagement(session->
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

            .addFilterBefore(new JwtFilter(this.jwtUtil), JwtLoginFilter.class)
            .addFilterAt(new JwtLoginFilter(authenticationManager(authenticationConfiguration), this.jwtUtil), UsernamePasswordAuthenticationFilter.class)

            .exceptionHandling(exception->{
                exception.authenticationEntryPoint(this.customAuthenticationEntryPoint);
                exception.accessDeniedHandler(this.customAccessDeniedHandler);
            });
            return http.build();
    }
}
