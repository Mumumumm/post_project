package com.example.post_project.data.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "posttbl")
public class PostEntity {
    @Id
    private String username;
    @Column
    private String title;
    @Column
    private String text;
    @Column
    private String author;

}
