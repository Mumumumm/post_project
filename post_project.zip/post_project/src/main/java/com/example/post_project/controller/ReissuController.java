package com.example.post_project.controller;

import com.example.post_project.jwt.JwtUtil;
import io.jsonwebtoken.ExpiredJwtException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class ReissuController {
    private final JwtUtil jwtUtil;
    @PostMapping(value = "/reissue")
    public ResponseEntity<String> reissue(HttpServletRequest request, HttpServletResponse response) {
        String refrest_token= null;
        Cookie[] cookies = request.getCookies();
        for(Cookie cookie : cookies){
            if(cookie.getName().equals("refrest")){
                refrest_token = cookie.getValue();
                break;
            }
        }
        if(refrest_token == null){
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("토근 null");
        }

        try{
            jwtUtil.isExpired(refrest_token);
        }catch (ExpiredJwtException e){
            return  ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("만료된 토큰");
        }

        String category =  jwtUtil.getCategory(refrest_token);
        if(!category.equals("refresh")){
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("s놈모 올여용");
        }

        String username = jwtUtil.getUsername(refrest_token);


        String access = this.jwtUtil.createToken("access",username,5000L);

        response.addHeader("Authorization", "Bearer "+ access);
        return ResponseEntity.status(HttpStatus.OK).body("토큰 발급 성공");
    }
}
