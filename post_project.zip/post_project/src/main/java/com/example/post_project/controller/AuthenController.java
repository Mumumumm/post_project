package com.example.post_project.controller;

import com.example.post_project.data.dto.AuthenDTO;
import com.example.post_project.service.AuthenticationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class AuthenController {
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationService authenticationService;

    @PostMapping(value = "/join")
    public ResponseEntity<String> join(@RequestBody AuthenDTO authenDTO) {
        if(this.authenticationService.isUsernameExists(authenDTO.getUsername())) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("이미 존재하는 아이디 입니다");
        }
        this.authenticationService.saveAuthen(authenDTO.getUsername(), authenDTO.getPassword());
        return ResponseEntity.status(HttpStatus.OK).body("가입 되었습니다");
    }
}
